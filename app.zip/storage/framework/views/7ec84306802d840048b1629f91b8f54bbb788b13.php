<!--Content Header (Page header) -->
<section class="content-header">
    <h1>
    <?php echo e($title); ?>

    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
    </ol> -->
</section>
<!-- Main content -->
<section class="content">
    <div class="box">
        <div class="box-header">
           <!--  <h3 class="box-title">Data Table With Full Features</h3> -->
            </div><!-- /.box-header -->
            <div class="" style="">
                <a href="<?php echo e(url('/Add-Product')); ?>" class="btn btn-primary btn-flat" style="float: right;margin-right: 40px;    margin-bottom: 2px;">Add Product</a>
            </div>
            
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Product Name</th>
                            <th>Portal</th>
                            <th>Country</th>
                            <th>Region Name</th>
                            <th>City</th>
                            <th>Zipcode</th>
                            <th>Network</th>  
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1; ?>
                        <?php $__currentLoopData = $Visitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($list->product->product_name); ?></td>
                            <td><?php echo e($list->product->portal->protal_name); ?></td>
                            <td><?php echo e($list->country_name); ?></td>
                            <td><?php echo e($list->regionName); ?></td>
                            <td><?php echo e($list->city); ?></td>
                            <td><?php echo e($list->zipcode); ?></td>  
                            <td><?php echo e($list->network_name); ?></td>                      
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                        
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>No.</th>
                        <th>Product Name</th>
                        <th>Portal</th>
                        <th>Country</th>
                        <th>Region Name</th>
                        <th>City</th>
                        <th>Zipcode</th>
                        <th>Network</th>
                    </tr>
                    </tfoot>
                </table>
                </div><!-- /.box-body -->
                </div><!-- /.box -->
                
                </section><!-- /.content<?php /**PATH C:\xampp\htdocs\laravel_visitors\resources\views/frontend/Componets/Visitor_List.blade.php ENDPATH**/ ?>