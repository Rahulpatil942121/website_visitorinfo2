<section class="content-header">
    <h1>
    Blank page
    <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Blank page</li>
    </ol>
</section>
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-8 m-auto">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title">Quick Example</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('/Submit-State')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="box-body">
                            <div class="form-group">
                                <input type="hidden" id="state_id" name="state_id" value="<?php if($state): ?><?php echo e($state->id); ?><?php endif; ?>" datalist="<?php if($state): ?><?php echo e($state->state_name); ?><?php endif; ?>">
                                <label for="exampleInputEmail1">Select State</label>
                                <select class="form-control" id="ddlstate" name="ddlstate" required="">
                                    
                                </select>
                                <?php if($errors->has('ddlstate')): ?> <p class="text-danger"><?php echo e($errors->first('ddlstate')); ?></p><?php endif; ?>
                            </div>
                            <?php if($state): ?>
                            <div class="form-group">
                                <label for="exampleInputFile">Existing State Image</label>
                                <img src="<?php echo e(asset($state->state_image)); ?>" class="img-thumbnail" style="width: 100px;height: 75px;">
                            </div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label for="exampleInputFile">Upload State Image</label>
                                <input type="file" id="exampleInputFile" name="state_image" accept="image/png, image/jpeg, image/jpg, image/gif" <?php if(!$state): ?> required="" <?php endif; ?>>
                                <p class="help-block">Image Only (png,jpeg,jpg,gif)</p>
                                <?php if($errors->has('state_image')): ?> <p class="text-danger"><?php echo e($errors->first('state_image')); ?></p><?php endif; ?>
                            </div>
                            
                            </div><!-- /.box-body -->
                            <div class="box-footer">
                                <button type="reset"  class="btn btn-secondary">Reset</button>
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                        </div><!-- /.box -->
                    </div>
                </div>
            </section><!-- /.content<?php /**PATH C:\xampp\htdocs\Recruitnxt\resources\views/frontend/Componets/Add_State.blade.php ENDPATH**/ ?>