 
<section class="content-header">
    <h1>
    <?php echo e($title); ?>

    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
    </ol> -->
</section>
<!-- Main content -->
<section class="content">
    <div class="box">
        <div class="box-header">
            <!-- <h3 class="box-title">Data Table With Full Features</h3> -->
            <!-- --------------------------------- -->
                <div class="d-flex">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul class="list-unstyled">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
            <!-- --------------------------------- -->
        </div><!-- /.box-header -->
            <div class="" style="">
                <span class="btn btn-primary btn-flat btn-sm" style="float: right;margin-right: 40px;margin-bottom: 2px;" data-toggle="modal" data-target="#myModal">Add Type</span>
            </div>
            
            <div class="box-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>User Type</th>
                            <th>Status</th>
                            <th>Action</th>                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1; ?>
                        <?php $__currentLoopData = $Usertype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($list->type_name); ?></td>
                            <td><?php if($list->status == 1): ?> Active <?php else: ?> D-Active <?php endif; ?></td>
                            <td>                                
                                <a href="<?php echo e(url('/Edit-Type')); ?>/<?php echo e($list->id); ?>" class="btn btn-info btn-sm" style="margin-right: 5px;"><i class="fa fa-fw fa-edit"></i></a>
                                <a href="<?php echo e(url('/Delete-Type')); ?>/<?php echo e($list->id); ?>" class="btn <?php if($list->status == 1): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-sm btn_delete" title="Change Status"><?php if($list->status == 1): ?> D-Active <?php else: ?> Active <?php endif; ?></a>
                            </td>                             
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                        
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>No.</th>
                         <th>User Type</th>
                        <th>Status</th>
                        <th>Action</th> 
                    </tr>
                    </tfoot>
                </table>
                </div><!-- /.box-body -->
                </div><!-- /.box -->
                
            </section><!-- /.content -->

           <!-- The Modal -->
        <div class="modal" id="myModal">
          <div class="modal-dialog">
            <div class="modal-content">

              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">Add User Type</h4>
               <!--  <button type="button" class="close" data-dismiss="modal">&times;</button> -->
              </div>
              <!-- Modal body -->
              <div class="modal-body">
               <form action="<?php echo e(url('/Add-User-Type')); ?>" method="post">
                <?php echo csrf_field(); ?>
                   <div class="form-group">
                       <span>User Type</span>
                       <input type="text" name="User_Type" class="form-control" placeholder="User Type" autocomplete="off" required="">
                   </div>
                   <div class="form-group">
                       <span>Status</span>
                        <select name="status" class="form-control" required="">
                            <option value="1">Active</option>
                            <option value="0">D-Active</option>
                        </select>
                   </div>
                   <div class="d-flex">
                       <button name="reset" class="btn btn-secondary btn-flat">Reset</button>
                       <button name="submit" class="btn btn-primary btn-flat">Submit</button>
                   </div>
               </form>
              </div>

              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
              </div>

            </div>
          </div>
        </div> 

        <!-- ------------------------------------------<?php /**PATH /home/apliju6h/productvisitor.duticorp.com/resources/views/frontend/Componets/Usertype.blade.php ENDPATH**/ ?>