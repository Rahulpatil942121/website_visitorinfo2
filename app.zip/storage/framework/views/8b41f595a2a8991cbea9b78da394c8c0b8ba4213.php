<?php echo $__env->make('frontend/Common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <?php if($flag == 1): ?>
      <?php echo $__env->make('frontend/Componets/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 2): ?>
      <?php echo $__env->make('frontend/Componets/Product_List', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 3): ?>
        <?php echo $__env->make('frontend/Componets/Portal_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 4): ?>
        <?php echo $__env->make('frontend/Componets/Add_Product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 5): ?>
        <?php echo $__env->make('frontend/Componets/Visitor_List', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 6): ?>
        <?php echo $__env->make('frontend/Componets/Edit_Portal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 7): ?>
        <?php echo $__env->make('frontend/Componets/Edit_Product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 8): ?>
        <?php echo $__env->make('frontend/Componets/List_Users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    <?php elseif($flag == 9): ?>
        <?php echo $__env->make('frontend/Componets/Usertype', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 10): ?>
        <?php echo $__env->make('frontend/Componets/Edit_Usertype', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 11): ?>
        <?php echo $__env->make('frontend/Componets/Add_Users', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 12): ?>
        <?php echo $__env->make('frontend/Componets/Edit_User', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 13): ?>
        <?php echo $__env->make('frontend/Componets/Profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php endif; ?>
</aside><!-- /.right-side -->
<?php echo $__env->make('frontend/Common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/apliju6h/productvisitor.duticorp.com/resources/views//frontend/Webviews/Manageviews.blade.php ENDPATH**/ ?>