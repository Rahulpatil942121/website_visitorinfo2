<section class="content-header">
    <h1>
    <?php echo e($title); ?>

    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Blank page</li>
    </ol> -->
</section>
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-8 m-auto">
            <!-- general form elements -->
            <div class="box box-primary" style="padding: 10px;">
                <div class="box-header">
                    <h3 class="box-title"><?php echo e($title); ?></h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form action="<?php echo e(url('/Update-User-Type')); ?>" method="post">
                <?php echo csrf_field(); ?>
                   <div class="form-group">
                       <span>User Type</span>
                       <input type="hidden" name="type_id" value="<?php echo e($type->id); ?>" class="form-control" required="">
                       <input type="text" name="User_Type" class="form-control" value="<?php echo e($type->type_name); ?>" placeholder="User Type" autocomplete="off" required="">
                        <?php if($errors->has('User_Type')): ?> <p class="text-danger"><?php echo e($errors->first('User_Type')); ?></p><?php endif; ?>
                   </div>
                   <div class="form-group">
                       <span>Status</span>
                        <select name="status" class="form-control" required="">
                            <option value="1" <?php if($type->status == 1): ?> selected <?php endif; ?>>Active</option>
                            <option value="0" <?php if($type->status == 0): ?> selected <?php endif; ?>>D-Active</option>
                        </select>
                         <?php if($errors->has('status')): ?> <p class="text-danger"><?php echo e($errors->first('status')); ?></p><?php endif; ?>
                   </div>
                   <div class="d-flex">
                       <button name="reset" class="btn btn-secondary btn-flat">Reset</button>
                       <button name="submit" class="btn btn-primary btn-flat">Submit</button>
                   </div>
               </form>
                        </div><!-- /.box -->
                    </div>
                </div>
            </section><!-- /.content<?php /**PATH /home/apliju6h/productvisitor.duticorp.com/resources/views/frontend/Componets/Edit_Usertype.blade.php ENDPATH**/ ?>