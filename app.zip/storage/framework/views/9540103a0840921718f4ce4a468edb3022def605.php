<section class="content-header">
    <h1>
    <?php echo e($title); ?>

    </h1>
    <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Blank page</li>
    </ol> -->
</section>
<!-- Main content -->
<section class="content">
    <div class="row">
        <div class="col-md-8 m-auto">
            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h3 class="box-title"><?php echo e($title); ?></h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="<?php echo e(url('/Update-User')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="box-body">
                            <div class="form-group">  
                                <label for="exampleInputEmail1">Select Type<small class="text-danger h4">*</small></label>
                                <input type="hidden" name="user_id" class="form-control" value="<?php echo e($User->id); ?>" required="">
                                <select class="form-control" id="ddltype" name="ddltype" required="">
                                    <option value="">Select Type</option>
                                    <?php $__currentLoopData = $Usertype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($list->id); ?>" <?php if($User->role): ?> selected <?php endif; ?>><?php echo e($list->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </select>
                                <?php if($errors->has('ddltype')): ?> <p class="text-danger"><?php echo e($errors->first('ddltype')); ?></p><?php endif; ?>
                            </div>
                            <div class="form-group">                                  
                                <label for="exampleInputEmail1">User Name <small class="text-danger h4">*</small></label>
                                <input type="text" name="user_name" placeholder="User Name" class="form-control" value="<?php echo e($User->name); ?>" required=""> 
                                <?php if($errors->has('user_name')): ?> <p class="text-danger"><?php echo e($errors->first('user_name')); ?></p><?php endif; ?>
                            </div> 
                            <div class="form-group">                                  
                                <label for="exampleInputEmail1">Login Email <small class="text-danger h4">*</small></label>
                                <input type="email" name="login_email" placeholder="Login Email ID" class="form-control" value="<?php echo e($User->email); ?>" required=""> 
                                <?php if($errors->has('login_email')): ?> <p class="text-danger"><?php echo e($errors->first('login_email')); ?></p><?php endif; ?>
                            </div>
                            <div class="form-group">                                  
                                <label for="exampleInputEmail1">Contact No. <small>(Optional)</small></label>
                                <input type="text" name="contact_no" class="form-control" value="<?php echo e($User->contact_no); ?>" placeholder="Contact No. (Only Number)" minlength="10" maxlength="10" autocomplete="off" required="">
                                <?php if($errors->has('contact_no')): ?> <p class="text-danger"><?php echo e($errors->first('contact_no')); ?></p><?php endif; ?>
                            </div>                            
                            <div class="form-group">
                               <span>Status <small class="text-danger h4">*</small></span>
                                <select name="status" class="form-control" required="">
                                    <option value="1" <?php if($User->status == 1): ?> selected <?php endif; ?> >Active</option>
                                    <option value="0" <?php if($User->status == 0): ?> selected <?php endif; ?>>D-Active</option>
                                </select>
                           </div>
                            </div><!-- /.box-body -->
                            <div class="box-footer">
                                <button type="reset"  class="btn btn-secondary">Reset</button>
                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                        </div><!-- /.box -->
                    </div>
                </div>
            </section><!-- /.content ---><?php /**PATH /home/apliju6h/productvisitor.duticorp.com/resources/views/frontend/Componets/Edit_User.blade.php ENDPATH**/ ?>