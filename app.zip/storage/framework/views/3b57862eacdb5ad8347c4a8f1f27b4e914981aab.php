<?php echo $__env->make('frontend/Common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Right side column. Contains the navbar and content of the page -->
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <?php if($flag == 1): ?>
      <?php echo $__env->make('frontend/Componets/home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 2): ?>
      <?php echo $__env->make('frontend/Componets/State_List', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 3): ?>
        <?php echo $__env->make('frontend/Componets/Add_State', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 4): ?>
        <?php echo $__env->make('frontend/Componets/City_List', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($flag == 5): ?>
        <?php echo $__env->make('frontend/Componets/Add_City', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
    <?php endif; ?>
</aside><!-- /.right-side -->
<?php echo $__env->make('frontend/Common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Recruitnxt\resources\views//frontend/Webviews/Manageviews.blade.php ENDPATH**/ ?>